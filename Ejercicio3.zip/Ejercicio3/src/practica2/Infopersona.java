
package practica2;

public class Infopersona {
    //Propiedades
    private String Nombre;
    private String Apellido;
    private String Telefono;
    private String Sexo;
    private String  Edad;
    private String Dirección;
    
    //Contructor de la clase 
    public Infopersona(String Nombre, String Apellido,String Telefono,String Sexo,String Edad, String Dirección) {
      this.Nombre = Nombre;
      this.Apellido = Apellido;
      this.Telefono = Telefono;
      this.Sexo = Sexo;
      this.Edad = Edad;
      this.Dirección = Dirección;
    }

    //Metodos de la clases
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getEdad() {
        return Edad;
    }

    public void setEdad(String Edad) {
        this.Edad = Edad;
    }

    public String getDirección() {
        return Dirección;
    }

    public void setDirección(String Dirección) {
        this.Dirección = Dirección;
    } 

    String getSex() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getDirec() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
